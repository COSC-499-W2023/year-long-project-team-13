from django.apps import AppConfig


class StreamConfig(AppConfig):
    name = 'stream'
