from django.contrib import admin
from . models import VidStream

admin.site.register(VidStream)
